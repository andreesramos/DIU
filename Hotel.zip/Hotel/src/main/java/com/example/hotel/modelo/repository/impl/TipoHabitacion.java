package com.example.hotel.modelo.repository.impl;

public enum TipoHabitacion {
    DOBLEUSOINDIVIDUAL, DOBLE, JUNIORSUITE, SUITE
}
