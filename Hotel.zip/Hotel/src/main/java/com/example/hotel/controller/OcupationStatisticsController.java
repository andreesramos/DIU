package com.example.hotel.controller;

public class OcupationStatisticsController {

}
