import './App.css'
import Conversor from './components/Conversor'

function App() {

  return (
    <>
      <Conversor></Conversor>
    </>
  )
}

export default App
